SELECT
    t_stamp,
    floatvalue
FROM sqlt_data
ORDER BY t_stamp DESC
LIMIT 10;